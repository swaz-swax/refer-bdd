package com.capgemini.ssms.exception;

public class ScheduledSessionException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public String message;
	public ScheduledSessionException(String message) {
		this.message=message;
	}
	
	public String getMessage() {
		return message;
	}
}
