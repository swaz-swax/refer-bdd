package com.capgemini.ssms.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.ssms.exception.ScheduledSessionException;
import com.capgemini.ssms.model.ScheduledSessions;
import com.capgemini.ssms.service.ITrainingService;

@Controller
public class TrainingController {

	@Autowired
	ITrainingService trainingService;

	@RequestMapping("/home")
	public String displayPage(Model model) 
	{
		try
		{
		String view = "ScheduledSessions";
		ArrayList<ScheduledSessions> list = trainingService.viewScheduledSession();
		model.addAttribute("list", list);
		return view;
		}
		catch(ScheduledSessionException e)
		{
			System.err.println(e.getMessage());
		}
		return null;
	}

	@RequestMapping("/session")
	public ModelAndView successPage(@RequestParam("sessionname") String sessionname) 
	{
	System.out.println(sessionname);
		/*try
		{
		String view = "";
		System.out.println(sessionname);
		//String sessionName = trainingService.findSessionName(sessionname);
		//model.addAttribute("sessionname", sessionName);
		view = "Success";
		return view;
		}
		catch(ScheduledSessionException e)
		{
			System.err.println(e.getMessage());
		}*/
		
		return new ModelAndView("Success","data",sessionname);
	}
}
