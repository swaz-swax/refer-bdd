/**
 * 
 */
package com.capgemini.ssms.dao;

import java.util.ArrayList;

import com.capgemini.ssms.exception.ScheduledSessionException;
import com.capgemini.ssms.model.ScheduledSessions;

/**
 * @author swtalukd
 *
 */
public interface ITrainingDAO 
{
	public ArrayList<ScheduledSessions> viewScheduledSession() throws ScheduledSessionException;

	public String findSessionName(String sessionname) throws ScheduledSessionException;
}
