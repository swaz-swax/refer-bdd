/**
 * 
 */
package com.capgemini.ssms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ssms.dao.ITrainingDAO;
import com.capgemini.ssms.exception.ScheduledSessionException;
import com.capgemini.ssms.model.ScheduledSessions;

/**
 * @author swtalukd
 *
 */
@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService 
{
	@Autowired
	ITrainingDAO trainingDAO;
	/* (non-Javadoc)
	 * @see com.capgemini.ssms.service.ITrainingService#viewScheduledSession()
	 */
	
	
	@Override
	public ArrayList<ScheduledSessions> viewScheduledSession() throws ScheduledSessionException 
	{
		return trainingDAO.viewScheduledSession();
	}
	

	/* (non-Javadoc)
	 * @see com.capgemini.ssms.service.ITrainingService#findSessionName()
	 */
	@Override
	public String findSessionName(String sessionname) throws ScheduledSessionException
	{	
		return trainingDAO.findSessionName(sessionname);
	}

}
