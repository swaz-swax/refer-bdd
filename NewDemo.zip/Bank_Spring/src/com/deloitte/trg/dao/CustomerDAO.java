package com.deloitte.trg.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.deloitte.trg.entity.CustomerEntity;
import com.deloitte.trg.model.Bank;
import com.deloitte.trg.service.CustomerException;
import com.deloitte.trg.utility.AppConfig;

@Repository
public class CustomerDAO implements ICustomerDAO{
	
	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public String addCustomer(Bank bank) throws CustomerException {
		Random rd1 = new Random();
		int accountNo = 1000000 + rd1.nextInt(900000);
		bank.setAccountNo(accountNo);
		Random rd2 = new Random();
		int accPin = 1000 + rd2.nextInt(9000);
		bank.setAccPin(accPin);	
		entityManager.persist(bank);
		return "Customer added Successfully";
		
	}

	@Override
	public String getBalance(int id, int pin) {
		String status="";
		Bank b1= entityManager.find(Bank.class, id);
		if((b1.getAccountNo()==id) && b1.getAccPin()==pin){
			double balance= b1.getBalance();
			status= "Your account balance is: "+balance;
		}else{
			status="Invalid credentials";
		}
		return status;
	}

	@Override
	public String deposit(int id, int accpin, double amount) {
		String status="";
		Bank b1= entityManager.find(Bank.class, id);
		if((b1.getAccountNo()==id) && (b1.getAccPin()==accpin)){
			double balance= b1.getBalance();
			balance= balance + amount;
			b1.setBalance(balance);
			entityManager.merge(b1);
			status="Your account balance after deposit is: "+balance;
		}else{
			status="Invalid account credentials";
		}
		return status;
	}

	@Override
	public String withdraw(int id, int accpin, double amount) {
		String status="";
		Bank b1= entityManager.find(Bank.class, id);
		if((b1.getAccountNo()==id) && (b1.getAccPin()==accpin)){
			double balance= b1.getBalance();
			if(balance > amount){
				balance= balance- amount;
				b1.setBalance(balance);
				entityManager.merge(b1);
				status="Your account balance after withdraw is: "+balance;
			}else{
				status="Insufficient balance in account";
			}
		}else{
			status="Invalid account credentials";
		}
		return status;
	}

	@Override
	public String transfer(int id1, int accpin1, double amount, int id2) {
		String status="";
		Bank b1= entityManager.find(Bank.class, id1);
		if((b1.getAccountNo()==id1) && (b1.getAccPin()==accpin1)){  //withdraw
			double balance= b1.getBalance();
			if(balance > amount){
				balance= balance - amount;
				b1.setBalance(balance);
				entityManager.merge(b1);
				status="Your account balance after transfer is: "+balance;
				Bank b2= entityManager.find(Bank.class, id2);
				if(b2.getAccountNo()== id2){
					double bal= b2.getBalance();
					bal= bal + amount;
					b2.setBalance(balance);
					entityManager.merge(b2);
					
				}else{
					status="Account "+id2+" is not valid";
				}
			}else{
				status="Insufficient balance";
			}
		}else{
			status="Invalid credentials";
		}
		return status;
	}

	/*@Override
	public List<CustomerEntity> getAllCustomerDetails() throws CustomerException {
		final Logger myLogger = Logger.getLogger(CustomerDAO.class);			
		String sql="From CustomerEntity";
		//EntityTransaction transaction=entityManager.getTransaction();
		try {
			//transaction.begin();
			Query query=entityManager.createQuery(sql);
			List<CustomerEntity> customerList=query.getResultList();			
			//transaction.commit();
			myLogger.info(AppConfig.PROPERTIES.getProperty("CUSTOMER_READALL.SUCCESS"));
			return customerList;
		}catch(PersistenceException e) {			
			myLogger.error(e.getMessage());		
			throw new CustomerException(e.getMessage());
		}catch(Exception e) {	
			myLogger.error(e.getMessage());
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public CustomerEntity getCustomerById(Integer ID) throws CustomerException {
		Logger myLogger=Logger.getLogger(CustomerDAO.class);
		try {
			 CustomerEntity customerEntity=entityManager.find(CustomerEntity.class, ID);
			 myLogger.info(AppConfig.PROPERTIES.getProperty("CUSTOMER_READ.SUCCESS"));
			 return customerEntity;
		}catch(PersistenceException e) {			
			myLogger.error(e.getMessage());		
			throw new CustomerException(e.getMessage());
		}catch(Exception e) {	
			myLogger.error(e.getMessage());
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public Integer deleteCustomer(Integer ID) throws CustomerException {
		Logger myLogger=Logger.getLogger(CustomerDAO.class);
		try {
			CustomerEntity customer=entityManager.find(CustomerEntity.class, ID);
			entityManager.remove(customer);
			myLogger.info(AppConfig.PROPERTIES.getProperty("CUSTOMER_DELETE.SUCCESS"));
			return 1;
		}catch(PersistenceException e) {
			throw new CustomerException(e.getMessage());
		}	
	}

	@Override
	public Integer updateCustomer(CustomerEntity customer) throws CustomerException {
		Logger myLogger=Logger.getLogger(CustomerDAO.class);
		try {
			entityManager.merge(customer);
			myLogger.info(AppConfig.PROPERTIES.getProperty("CUSTOMER_UPDATE.SUCCESS"));
			return 1;
		}catch(PersistenceException e) {
			throw new CustomerException(e.getMessage());
		}	
	}*/

}
